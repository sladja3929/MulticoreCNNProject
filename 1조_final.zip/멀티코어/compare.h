#ifndef _COMPARE_H
#define _COMPARE_H

int compare(char* argv);

#endif 